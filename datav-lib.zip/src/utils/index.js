export function debounce (callback, delay) {
  let task = null
  return function () {
    task && clearTimeout(task)
    task = setTimeout(() => {
      callback.apply(this, arguments)
      task = null
    }, delay)
  }
}