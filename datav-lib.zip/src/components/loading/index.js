import Loading from './Loading.vue'

export default function (Vue) {
  Vue.component(Loading.name, Loading)
}