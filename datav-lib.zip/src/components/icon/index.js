import Icon from './Icon.vue'

export default function (Vue) {
  Vue.component(Icon.name, Icon)
}