import CountTo from './vue-countTo.vue';

export default function (Vue) {
  Vue.component(CountTo.name, CountTo)
}
