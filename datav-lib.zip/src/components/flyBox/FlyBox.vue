<template>
  <div class="fly-box" :ref="refName">
    <svg :width="width" :height="height">
      <defs>
        <path :id="pathId" :d="path" fill="none"></path>
        <radialGradient
          :id="radialGradientId"
          cx="50%"
          cy="50%"
          fx="100%"
          fy="50%"
          r="50%"
        >
          <stop offset="0%" stop-color="#fff" stop-opacity="1"></stop>
          <stop offset="100%" stop-color="#fff" stop-opacity="0"></stop>
        </radialGradient>
        <mask :id="maskId">
          <circle
            cx="0"
            cy="0"
            :r="starLength"
            :fill="`url(#${radialGradientId})`"
          >
            <animateMotion
              :path="path"
              :dur="`${duration}s`"
              rotate="auto"
              repeatCount="indefinite"
            ></animateMotion>
          </circle>
        </mask>
      </defs>
      <use
        :href="`#${pathId}`"
        :stroke-width="lineWidth"
        :stroke="lineColor"
      ></use>
      <use
        :href="`#${pathId}`"
        :stroke-width="starWidth"
        :stroke="starColor"
        :mask="`url(#${maskId})`"
      ></use>
    </svg>
    <div class="fly-box-content">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import { computed, ref, onMounted, getCurrentInstance } from 'vue'
import { v4 as uuidv4 } from 'uuid'
export default {
  name: 'FlyBox',
  props: {
    lineWidth: {
      type: [Number, String],
      default: 1
    },
    lineColor: {
      type: String,
      default: '#235fa7'
    },
    starWidth: {
      type: [Number, String],
      default: 3
    },
    starLength: {
      type: [Number, String],
      default: 50
    },
    starColor: {
      type: String,
      default: '#4fd2dd'
    },
    duration: {
      type: [Number, String],
      default: 6
    }
  },
  setup () {
    // 获取唯一的uuid
    const uuid = uuidv4()
    const width = ref(0)
    const height = ref(0)
    const refName = 'flyBox'
    // 轨迹pathId
    const pathId = `${refName}_path_${uuid}`
    // 轨迹蒙版Id
    const maskId = `${refName}_mask_${uuid}`
    // 圆形渐变Id
    const radialGradientId = `${refName}_radialGradient_${uuid}`
    // 通过计算属性自动计算出path，上下左右各保留5px间距
    const path = computed(() => `M5 5 L${width.value - 5} 5 L${width.value - 5} ${height.value - 5} L5 ${height.value - 5} Z`)

    const init = () => {
      // getCurrentInstance 方法获取当前组件的实例
      const instance = getCurrentInstance()
      // svg占满父元素，所以可以动态获取父元素宽高来指定其宽高尺寸
      const dom = instance.ctx.$refs[refName]
      width.value = dom.clientWidth
      height.value = dom.clientHeight
    }

    onMounted(() => {
      init()
    })

    return {
      width,
      height,
      refName,
      path,
      pathId,
      maskId,
      radialGradientId
    }
  }
}
</script>

<style lang="scss" scoped>
.fly-box {
  position: relative;
  width: 100%;
  height: 100%;
  svg {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
  .fly-box-content {
    width: 100%;
    height: 100%;
    padding: 10px;
    box-sizing: border-box;
  }
}
</style>