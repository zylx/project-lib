import FlyBox from './FlyBox.vue'

export default function (Vue) {
  Vue.component(FlyBox.name, FlyBox)
}