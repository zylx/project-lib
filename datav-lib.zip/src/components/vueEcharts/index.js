import MyEcharts from './VueEcharts.vue'

export default function (Vue) {
  Vue.component(MyEcharts.name, MyEcharts)
}