<template>
  <div class="echarts" :id="chartId"></div>
</template>

<script>
import { onMounted, watch } from 'vue'
import Echarts from 'echarts'
import { v4 as uuidv4 } from 'uuid'
export default {
  name: 'VueEcharts',
  props: {
    options: Object,
    theme: [String, Object]
  },
  setup (ctx) {
    let chart = null
    let chartId = 'chart-' + uuidv4()

    const initChart = () => {
      if (!chart) {
        const dom = document.getElementById(chartId)
        chart = Echarts.init(dom, ctx.theme)
      }
      if (ctx.options) {
        chart.setOption(ctx.options)
      }
    }

    onMounted(() => {
      initChart()
    })

    watch(() => ctx.options, () => {
      initChart()
    })

    return {
      chartId
    }
  }
}
</script>

<style lang="scss" scoped>
.echarts {
  width: 100%;
  height: 100%;
}
</style>
