<template>
  <div id="datav-container" :ref="refName">
    <template v-if="ready">
      <slot></slot>
    </template>
  </div>
</template>

<script>
import { ref, getCurrentInstance, onMounted, onUnmounted, nextTick } from 'vue'
import { debounce } from '../../utils'
export default {
  name: "DatavContainer",
  props: {
    options: Object
  },
  setup (ctx) {
    const refName = 'datavContainer'
    const ready = ref(false)
    const width = ref(0)
    const height = ref(0)
    // 画布宽高
    const originalWidth = ref(0)
    const originalHeight = ref(0)
    let context, dom, observer

    // 初始化，设置容器宽高
    const initSize = () => {
      return new Promise((resolve) => {
        // 确保页面渲染更新后执行
        nextTick(() => {
          // 获取容器元素尺寸
          if (ctx.options && ctx.options.width && ctx.options.height) {
            width.value = ctx.options.width
            height.value = ctx.options.height
          } else {
            width.value = dom.clientWidth
            height.value = dom.clientHeight
          }
          // 获取屏幕尺寸，首次加载时，只获取一次
          if (!originalWidth.value || !originalHeight.value) {
            originalWidth.value = window.screen.width
            originalHeight.value = window.screen.height
          }
          console.log(width.value, height.value, originalWidth.value, originalHeight.value)
          resolve()
        })
      })
    }

    // 更新容器宽高
    const updateSize = () => {
      if (width.value && height.value) {
        dom.style.width = `${width.value}px`
        dom.style.height = `${height.value}px`
      } else {
        dom.style.width = `${originalWidth.value}px`
        dom.style.height = `${originalHeight.value}px`
      }
    }

    // 更新容器缩放比例
    const updateScale = () => {
      // 获取真实视口（可视区域）宽高
      const currentWidth = document.body.clientWidth
      const currentHeight = document.body.clientHeight
      console.log(currentWidth, currentHeight)
      // 获取大屏最终的宽高
      const realWidth = width.value || originalWidth.value
      const realHeight = height.value || originalHeight.value
      console.log(realWidth, realHeight)
      // 计算缩放比例
      const widthScale = currentWidth / realWidth
      const heightScale = currentHeight / realHeight
      // 设置容器缩放比例
      dom && (dom.style.transform = `scale(${widthScale}, ${heightScale})`)
    }

    // 缩放操作
    const onResize = async () => {
      console.log('resize');
      await initSize()
      updateScale()
    }

    // 监听属性变化
    const onMutationObserver = () => {
      const MutationObserver = window.MutationObserver
      observer = new MutationObserver(onResize)
      observer.observe(dom, {
        atrributes: true,
        attributeFilter: ['style'],
        attributeOldValue: true
      })
    }

    const unOnMutationServer = () => {
      if (observer) {
        observer.disconnect()
        observer.takeRecords()
        observer = null
      }
    }

    onMounted(async () => {
      ready.value = false
      context = getCurrentInstance().ctx
      dom = context.$refs[refName]
      await initSize()
      updateSize()
      updateScale()
      window.addEventListener('resize', debounce(onResize, 100))
      onMutationObserver()
      ready.value = true
    })

    //移除 resize 事件
    onUnmounted(() => {
      window.removeEventListener('resize', onResize)
      unOnMutationServer()
    })

    return {
      refName,
      ready
    }
  }
}
</script>

<style lang="scss" scoped>
#datav-container {
  position: fixed;
  top: 0;
  left: 0;
  transform-origin: left top; // 重点，改变元素的原点位置，置于屏幕左上角，容器中内容也会跟着跑到左上角，这个属性的默认值是 center center
  overflow: hidden;
  z-index: 999;
}
</style>