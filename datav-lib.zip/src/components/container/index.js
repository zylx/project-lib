import Container from './Container.vue'

export default function (Vue) {
  Vue.component(Container.name, Container)
}