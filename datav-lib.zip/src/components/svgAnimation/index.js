import SvgAnimation from './SvgAnimation.vue'

export default function (Vue) {
  Vue.component(SvgAnimation.name, SvgAnimation)
}