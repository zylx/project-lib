import ScrollList from './ScrollList.vue'

export default function (Vue) {
  Vue.component(ScrollList.name, ScrollList)
}