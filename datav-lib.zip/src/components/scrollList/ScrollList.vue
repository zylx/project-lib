<template>
  <div class="scroll-list" :id="id">
    <div
      class="list-header"
      :style="{
        backgroundColor: config.headerBgColor,
        height: config.headerHeight,
      }"
    >
      <div
        class="header-item"
        v-for="(item, index) in headerData"
        :key="item + index"
        :style="{ width: columnWidths[index], ...headerStyle[index] }"
        v-html="item"
      ></div>
    </div>
    <div class="list-rows" v-for="(row, index) in rowsData" :key="index">
      <div
        class="list-cols"
        v-for="(col, index) in row"
        :key="col + index"
        :style="{ width: columnWidths[index] }"
        v-html="col"
      ></div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { v4 as uuidv4 } from 'uuid'
import cloneDeep from 'lodash/cloneDeep'
import assign from 'lodash/assign'
import useScreen from '../../hooks/useScreen'

const defaultConfig = {
  headerData: [], // 标题数据，格式['a', 'b', 'c', ...]
  headerStyle: [], // 标题样式，格式[{}, {}, {}, ...]，与上面一一对应
  headerHeight: '35px', // 标题栏高度
  headerBgColor: 'rgb(90,90,90)', // 标题栏背景杨色
  headerIndex: false, // 是否显示序号
  headerIndexContent: '#',
  headerIndexStyle: { width: '50px' },
  data: [] // 滚动区域数据，二维数组
}

export default {
  name: 'ScrollList',
  props: {
    config: {
      type: Object,
      default: () => ({})
    }
  },
  setup (props) {
    const id = 'scroll-list-' + uuidv4()
    const { width, height } = useScreen(id)
    const actualConfig = ref({})
    const headerData = ref([])
    const headerStyle = ref([])
    const columnWidths = ref([])
    const rowsData = ref([])
    console.log(width)
    console.log(height)

    // 动态计算每一列宽度
    const getColumnWidths = (headerData, headerStyle) => {
      // 已使用的自定义宽度总计
      let usedWidth = 0
      // 已使用的自定义宽度列总计
      let usedColumnCount = 0
      headerStyle.forEach((style) => {
        // 如果自定了宽度，则计算自定义宽度的总宽度
        if (style.width) {
          usedWidth += parseInt(style.width)
          usedColumnCount++
        }
      });
      // 计算未定义的平均列宽，则由剩下的宽度除以未定义宽度的列数
      const avgWidth = (width.value - usedWidth) / (headerData.length - usedColumnCount)
      const columnWidths = new Array(headerData.length).fill(`${avgWidth}px`)
      // 再次循环遍历，更新 columnWidths 中对应的元素宽度（整合后的宽度）
      headerStyle.forEach((style, index) => {
        if (style.width) {
          columnWidths[index] = `${parseInt(style.width)}px`
        }
      })
      return columnWidths
    }

    // 标题栏配置处理
    const handleHeader = (config) => {
      if (config.headerData.length === 0) return
      const _headerData = cloneDeep(config.headerData)
      const _headerStyle = cloneDeep(config.headerStyle)
      if (config.headerIndex) {
        _headerData.unshift(config.headerIndexContent)
        _headerStyle.unshift(config.headerIndexStyle)
      }
      headerData.value = _headerData
      headerStyle.value = _headerStyle
      columnWidths.value = getColumnWidths(_headerData, _headerStyle)
    }

    // 滚动行内容配置处理
    const handleRows = (config) => {
      const _rowsData = cloneDeep(config.data)
      if (config.headerIndex) {
        _rowsData.forEach((rows, index) => {
          rows.unshift(index + 1)
        })
      }
      rowsData.value = _rowsData
    }

    onMounted(() => {
      const _actualConfig = assign(defaultConfig, props.config)
      handleHeader(_actualConfig)
      handleRows(_actualConfig)
      actualConfig.value = _actualConfig
    })

    return {
      id,
      headerData,
      rowsData,
      headerStyle,
      columnWidths
    }
  }
}
</script>

<style lang="scss" scoped>
.scroll-list {
  width: 100%;
  height: 100%;
  .list-header {
    display: flex;
    align-items: center;
    .header-item {
      padding: 0 10px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      font-size: 15px;
      box-sizing: border-box;
    }
  }
  .list-rows {
    display: flex;
    .list-cols {
      font-size: 28px;
    }
  }
}
</style>