import Icon from './components/icon'
// import SvgAnimation from './components/svgAnimation'
import Loading from './components/loading'
import FlyBOx from './components/flyBox'
import Container from './components/container'
import CountTo from './components/vueCountTo'
import VueEcharts from './components/vueEcharts'
import ScrollList from './components/scrollList'

export default function (Vue) {
  Vue.use(Icon)
  // Vue.use(SvgAnimation)
  Vue.use(Loading)
  Vue.use(FlyBOx)
  Vue.use(Container)
  Vue.use(CountTo)
  Vue.use(VueEcharts)
  Vue.use(ScrollList)
}